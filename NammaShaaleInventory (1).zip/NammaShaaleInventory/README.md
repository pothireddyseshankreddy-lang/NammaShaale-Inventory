# 🏫 Namma-Shaale Inventory

**A Digital Asset Auditor for Primary & Secondary Schools**

---

## 📌 Overview

Namma-Shaale Inventory is an Android application that helps teachers and school administrators track, audit, and manage school assets — including sports kits, lab equipment, tablets, and furniture. It ensures every government-funded resource is properly maintained and accounted for.

---

## ✨ Features

| Feature | Description |
|---|---|
| 📦 **Asset Register** | Add assets with name, serial number, category, location, and photo |
| 🩺 **Monthly Health Check** | Bulk-update condition of up to 50 assets in under 2 minutes |
| ⚠️ **Issue Log** | Log lost/damaged/stolen items with date and reason |
| 🔧 **Repair Requests** | Submit repair requests to SDMC with priority levels |
| 📋 **Summary Report** | Generate and share a full health report via WhatsApp, Email, etc. |
| 📷 **CameraX Integration** | Capture photos of assets for visual documentation |

---

## 🏗️ Architecture

```
MVVM + Repository Pattern
├── UI Layer        → Fragments, Activities, Adapters, ViewModels
├── Data Layer      → Room DB, DAOs, Repository
└── Entities        → Asset, HealthCheck, IssueLog, RepairRequest
```

---

## 🛠️ Tech Stack

- **Language:** Kotlin
- **Architecture:** MVVM + LiveData + Repository
- **Database:** Room (SQLite)
- **Camera:** CameraX
- **Image Loading:** Glide
- **UI:** Material Design 3, ConstraintLayout, RecyclerView
- **Navigation:** Jetpack Navigation Component
- **Async:** Kotlin Coroutines

---

## 🚀 Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- JDK 17

### Steps
1. **Clone / Extract** the project folder
2. Open **Android Studio** → `File` → `Open` → Select `NammaShaaleInventory/`
3. Wait for Gradle sync to complete
4. Connect an Android device (API 24+) or launch an emulator
5. Click ▶️ **Run**

---

## 📱 App Flow

```
Dashboard
  ├── Total / Working / Repair / Broken counters
  ├── [Start Health Check] → Bulk condition update screen
  ├── [Add Asset]          → Asset Register
  └── [Generate Report]    → Shareable PDF-style summary

Bottom Navigation
  ├── 🏠 Dashboard
  ├── 📦 Assets        → Search, filter by category, tap for details
  ├── ⚠️ Issues        → Open/All tab, resolve issues
  └── 🔧 Repairs       → Pending/All tab, approve & complete
```

---

## 🎯 Success Criteria Met

- ✅ **Monthly Health Check** — 10 items checkable in under 2 minutes using bulk UI
- ✅ **Summary Report** — Shareable via Android Share Sheet (WhatsApp, Gmail, etc.)
- ✅ **Professional UI** — Material Design 3 with color-coded Green/Yellow/Red status
- ✅ **Photo Documentation** — CameraX captures and stores asset photos
- ✅ **Offline First** — Room DB works fully offline

---

## 📂 Project Structure

```
app/src/main/
├── java/com/nammashaaleinventory/
│   ├── data/
│   │   ├── dao/           (AssetDao, HealthCheckDao, IssueLogDao, RepairRequestDao)
│   │   ├── entities/      (Asset, HealthCheck, IssueLog, RepairRequest)
│   │   ├── repository/    (AssetRepository)
│   │   └── AppDatabase.kt
│   ├── ui/
│   │   ├── dashboard/     (DashboardFragment, DashboardViewModel)
│   │   ├── assets/        (AssetsFragment, AssetAdapter, AddEditAsset, AssetDetail)
│   │   ├── healthcheck/   (HealthCheckActivity, HealthCheckViewModel, Adapter)
│   │   ├── issuelog/      (IssueLogFragment, IssueLogViewModel, Adapter)
│   │   ├── repair/        (RepairFragment, RepairViewModel, Adapter)
│   │   ├── reports/       (ReportActivity, ReportViewModel)
│   │   ├── camera/        (CameraActivity — CameraX)
│   │   └── MainActivity.kt
│   ├── utils/
│   │   └── DateUtils.kt
│   └── NammaShaaleApp.kt
└── res/
    ├── layout/    (15 XML layouts)
    ├── drawable/  (14 vector icons + shape drawables)
    ├── navigation/nav_graph.xml
    ├── menu/      (bottom_nav, assets, asset_detail)
    ├── values/    (colors, strings, themes)
    └── xml/       (file_paths for FileProvider)
```

---

## 🏆 Impact

- **Resource Optimization** — Track every taxpayer-funded asset
- **Educational Quality** — Keep labs and sports rooms functional
- **Accountability** — Monthly audits create a culture of asset care

---

*Built for the Namma-Shaale initiative — Karnataka Government School Asset Management*
