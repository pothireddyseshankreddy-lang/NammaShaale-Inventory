package com.nammashaaleinventory.ui.reports

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.databinding.ActivityReportBinding
import com.nammashaaleinventory.utils.DateUtils

class ReportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReportBinding

    private val viewModel: ReportViewModel by viewModels {
        ReportViewModelFactory((application as NammaShaaleApp).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Summary Report"

        setupButtons()
        observeData()

        viewModel.generateReport()
    }

    private fun setupButtons() {
        binding.btnShareReport.setOnClickListener {
            val reportText = viewModel.reportText.value
            if (reportText != null) {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Namma-Shaale Asset Health Report - ${DateUtils.formatDate(System.currentTimeMillis())}")
                    putExtra(Intent.EXTRA_TEXT, reportText)
                }
                startActivity(Intent.createChooser(shareIntent, "Share Report"))
            }
        }

        binding.btnRefreshReport.setOnClickListener {
            viewModel.generateReport()
        }
    }

    private fun observeData() {
        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
            binding.scrollReport.visibility = if (isLoading) View.GONE else View.VISIBLE
        }

        viewModel.reportData.observe(this) { report ->
            if (report != null) {
                binding.apply {
                    tvReportDate.text = "Generated: ${DateUtils.formatDateTime(System.currentTimeMillis())}"
                    tvTotalAssets.text = report.totalAssets.toString()
                    tvWorkingCount.text = report.workingCount.toString()
                    tvNeedsRepairCount.text = report.needsRepairCount.toString()
                    tvBrokenCount.text = report.brokenCount.toString()
                    tvPendingRepairs.text = report.pendingRepairs.toString()
                    tvUnresolvedIssues.text = report.unresolvedIssues.toString()
                    tvHealthScore.text = "${report.healthScore}%"

                    // Health score color
                    val scoreColor = when {
                        report.healthScore >= 80 -> com.nammashaaleinventory.R.color.condition_green
                        report.healthScore >= 50 -> com.nammashaaleinventory.R.color.condition_yellow
                        else -> com.nammashaaleinventory.R.color.condition_red
                    }
                    tvHealthScore.setTextColor(getColor(scoreColor))
                    progressHealthScore.progress = report.healthScore

                    // Category breakdown
                    tvCategoryBreakdown.text = report.categoryBreakdown.entries
                        .joinToString("\n") { "  ${it.key}: ${it.value} items" }

                    // Recent issues
                    if (report.recentIssues.isNotEmpty()) {
                        tvRecentIssues.text = report.recentIssues.joinToString("\n") { "  • $it" }
                    } else {
                        tvRecentIssues.text = "  No recent issues"
                    }
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
