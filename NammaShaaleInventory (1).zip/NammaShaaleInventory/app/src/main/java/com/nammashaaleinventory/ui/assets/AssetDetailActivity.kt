package com.nammashaaleinventory.ui.assets

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.R
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.databinding.ActivityAssetDetailBinding
import com.nammashaaleinventory.ui.issuelog.IssueLogAdapter
import com.nammashaaleinventory.ui.issuelog.IssueLogViewModel
import com.nammashaaleinventory.ui.issuelog.IssueLogViewModelFactory
import com.nammashaaleinventory.ui.repair.RepairRequestAdapter
import com.nammashaaleinventory.ui.repair.RepairViewModel
import com.nammashaaleinventory.ui.repair.RepairViewModelFactory
import com.nammashaaleinventory.utils.DateUtils
import java.io.File

class AssetDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAssetDetailBinding
    private var currentAsset: Asset? = null
    private var assetId: Long = -1

    private val assetsViewModel: AssetsViewModel by viewModels {
        AssetsViewModelFactory((application as NammaShaaleApp).repository)
    }

    companion object {
        const val EXTRA_ASSET_ID = "extra_asset_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAssetDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        assetId = intent.getLongExtra(EXTRA_ASSET_ID, -1L)
        if (assetId == -1L) { finish(); return }

        observeAsset()
        setupClickListeners()
    }

    private fun observeAsset() {
        assetsViewModel.run {} // ensure viewmodel initialized
        (application as NammaShaaleApp).repository.getAssetById(assetId).observe(this) { asset ->
            if (asset != null) {
                currentAsset = asset
                populateDetails(asset)
            }
        }
    }

    private fun populateDetails(asset: Asset) {
        supportActionBar?.title = asset.name

        binding.apply {
            tvDetailName.text = asset.name
            tvDetailSerial.text = "Serial: ${asset.serialNumber}"
            tvDetailCategory.text = asset.category
            tvDetailLocation.text = if (asset.location.isNotBlank()) asset.location else "Location not set"
            tvDetailDescription.text = if (asset.description.isNotBlank()) asset.description else "No description"
            tvDetailAddedDate.text = "Added: ${DateUtils.formatDate(asset.addedDate)}"
            tvDetailLastUpdated.text = "Last Updated: ${DateUtils.formatDate(asset.lastUpdated)}"

            val (conditionText, conditionColor) = when (asset.condition) {
                "WORKING" -> "Working" to R.color.condition_green
                "NEEDS_REPAIR" -> "Needs Repair" to R.color.condition_yellow
                "BROKEN" -> "Broken" to R.color.condition_red
                else -> "Unknown" to R.color.condition_grey
            }
            tvDetailCondition.text = conditionText
            tvDetailCondition.setBackgroundTintList(
                ContextCompat.getColorStateList(this@AssetDetailActivity, conditionColor)
            )
            cardConditionBanner.setCardBackgroundColor(
                ContextCompat.getColor(this@AssetDetailActivity, conditionColor)
            )

            asset.photoPath?.let { path ->
                val file = File(path)
                if (file.exists()) {
                    Glide.with(this@AssetDetailActivity).load(file).centerCrop().into(ivDetailPhoto)
                    ivDetailPhoto.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnEditAsset.setOnClickListener {
            val intent = Intent(this, AddEditAssetActivity::class.java)
            intent.putExtra(AddEditAssetActivity.EXTRA_ASSET_ID, assetId)
            startActivity(intent)
        }

        binding.btnLogIssue.setOnClickListener {
            val repo = (application as NammaShaaleApp).repository
            val dialog = LogIssueDialog.newInstance(assetId)
            dialog.show(supportFragmentManager, "log_issue")
        }

        binding.btnRequestRepair.setOnClickListener {
            val dialog = RequestRepairDialog.newInstance(assetId)
            dialog.show(supportFragmentManager, "request_repair")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.asset_detail_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> { finish(); true }
            R.id.action_delete_asset -> {
                showDeleteConfirmation()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showDeleteConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Remove Asset")
            .setMessage("Are you sure you want to remove '${currentAsset?.name}'? This action cannot be undone.")
            .setPositiveButton("Remove") { _, _ ->
                assetsViewModel.deleteAsset(assetId)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
