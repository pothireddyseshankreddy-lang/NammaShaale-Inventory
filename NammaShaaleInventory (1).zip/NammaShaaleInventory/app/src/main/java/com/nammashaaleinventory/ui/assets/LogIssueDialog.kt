package com.nammashaaleinventory.ui.assets

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.data.entities.IssueLog
import com.nammashaaleinventory.databinding.DialogLogIssueBinding
import com.nammashaaleinventory.ui.issuelog.IssueLogViewModel
import com.nammashaaleinventory.ui.issuelog.IssueLogViewModelFactory

class LogIssueDialog : DialogFragment() {

    private var _binding: DialogLogIssueBinding? = null
    private val binding get() = _binding!!

    private val viewModel: IssueLogViewModel by viewModels {
        IssueLogViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    companion object {
        private const val ARG_ASSET_ID = "asset_id"

        fun newInstance(assetId: Long): LogIssueDialog {
            return LogIssueDialog().apply {
                arguments = Bundle().apply { putLong(ARG_ASSET_ID, assetId) }
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogLogIssueBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val issueTypes = arrayOf("Lost", "Damaged", "Stolen", "Malfunction", "Other")
        binding.actvIssueType.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, issueTypes)
        )
        binding.actvIssueType.setText(issueTypes[0], false)

        binding.btnSubmitIssue.setOnClickListener {
            val assetId = requireArguments().getLong(ARG_ASSET_ID)
            val issueTypeText = binding.actvIssueType.text.toString()
            val description = binding.etIssueDescription.text?.toString()?.trim() ?: ""
            val reportedBy = binding.etReportedBy.text?.toString()?.trim() ?: ""

            if (description.isBlank()) {
                binding.tilIssueDescription.error = "Please describe the issue"
                return@setOnClickListener
            }

            val issueType = when (issueTypeText) {
                "Lost" -> "LOST"
                "Damaged" -> "DAMAGED"
                "Stolen" -> "STOLEN"
                "Malfunction" -> "MALFUNCTION"
                else -> "OTHER"
            }

            val issueLog = IssueLog(
                assetId = assetId,
                issueType = issueType,
                description = description,
                reportedBy = reportedBy
            )
            viewModel.insertIssueLog(issueLog)
            Toast.makeText(requireContext(), "Issue logged successfully", Toast.LENGTH_SHORT).show()
            dismiss()
        }

        binding.btnCancelIssue.setOnClickListener { dismiss() }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
