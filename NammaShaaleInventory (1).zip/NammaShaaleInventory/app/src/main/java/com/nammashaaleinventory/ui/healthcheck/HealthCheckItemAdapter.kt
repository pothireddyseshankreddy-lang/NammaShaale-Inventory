package com.nammashaaleinventory.ui.healthcheck

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammashaaleinventory.R
import com.nammashaaleinventory.databinding.ItemHealthCheckBinding

class HealthCheckItemAdapter(
    private val onConditionChanged: (assetId: Long, condition: String, notes: String) -> Unit
) : ListAdapter<HealthCheckItem, HealthCheckItemAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHealthCheckBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun markAllWorking() {
        val items = currentList.toMutableList()
        items.forEachIndexed { index, item ->
            if (!item.isChecked) {
                onConditionChanged(item.asset.id, "WORKING", "")
            }
        }
    }

    inner class ViewHolder(private val binding: ItemHealthCheckBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: HealthCheckItem) {
            binding.apply {
                tvHcAssetName.text = item.asset.name
                tvHcSerialNumber.text = item.asset.serialNumber
                tvHcCategory.text = item.asset.category

                // Set checked state visual
                val isChecked = item.isChecked
                cardHcItem.alpha = if (isChecked) 1.0f else 0.85f

                if (isChecked) {
                    val color = when (item.selectedCondition) {
                        "WORKING" -> R.color.condition_green
                        "NEEDS_REPAIR" -> R.color.condition_yellow
                        "BROKEN" -> R.color.condition_red
                        else -> R.color.condition_grey
                    }
                    viewHcStatusBar.setBackgroundColor(ContextCompat.getColor(root.context, color))
                    ivHcChecked.setImageResource(R.drawable.ic_check_circle)
                    ivHcChecked.setColorFilter(ContextCompat.getColor(root.context, R.color.condition_green))
                } else {
                    viewHcStatusBar.setBackgroundColor(ContextCompat.getColor(root.context, R.color.condition_grey))
                    ivHcChecked.setImageResource(R.drawable.ic_radio_unchecked)
                    ivHcChecked.setColorFilter(ContextCompat.getColor(root.context, R.color.text_secondary))
                }

                // Previous condition hint
                tvHcPrevCondition.text = "Previous: ${formatCondition(item.asset.condition)}"

                // Condition buttons
                btnWorking.isSelected = item.selectedCondition == "WORKING" && item.isChecked
                btnNeedsRepair.isSelected = item.selectedCondition == "NEEDS_REPAIR" && item.isChecked
                btnBroken.isSelected = item.selectedCondition == "BROKEN" && item.isChecked

                btnWorking.setOnClickListener {
                    val notes = etHcNotes.text?.toString() ?: ""
                    onConditionChanged(item.asset.id, "WORKING", notes)
                }

                btnNeedsRepair.setOnClickListener {
                    val notes = etHcNotes.text?.toString() ?: ""
                    onConditionChanged(item.asset.id, "NEEDS_REPAIR", notes)
                }

                btnBroken.setOnClickListener {
                    val notes = etHcNotes.text?.toString() ?: ""
                    onConditionChanged(item.asset.id, "BROKEN", notes)
                }
            }
        }

        private fun formatCondition(condition: String) = when (condition) {
            "WORKING" -> "Working"
            "NEEDS_REPAIR" -> "Needs Repair"
            "BROKEN" -> "Broken"
            else -> "Unknown"
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<HealthCheckItem>() {
        override fun areItemsTheSame(oldItem: HealthCheckItem, newItem: HealthCheckItem) =
            oldItem.asset.id == newItem.asset.id

        override fun areContentsTheSame(oldItem: HealthCheckItem, newItem: HealthCheckItem) =
            oldItem == newItem
    }
}
