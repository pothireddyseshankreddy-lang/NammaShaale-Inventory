package com.nammashaaleinventory.data.repository

import androidx.lifecycle.LiveData
import com.nammashaaleinventory.data.dao.AssetDao
import com.nammashaaleinventory.data.dao.HealthCheckDao
import com.nammashaaleinventory.data.dao.IssueLogDao
import com.nammashaaleinventory.data.dao.RepairRequestDao
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.data.entities.HealthCheck
import com.nammashaaleinventory.data.entities.IssueLog
import com.nammashaaleinventory.data.entities.RepairRequest

class AssetRepository(
    private val assetDao: AssetDao,
    private val healthCheckDao: HealthCheckDao,
    private val issueLogDao: IssueLogDao,
    private val repairRequestDao: RepairRequestDao
) {

    // Assets
    val allAssets: LiveData<List<Asset>> = assetDao.getAllActiveAssets()
    val totalCount: LiveData<Int> = assetDao.getTotalAssetsCount()
    val workingCount: LiveData<Int> = assetDao.getWorkingCount()
    val needsRepairCount: LiveData<Int> = assetDao.getNeedsRepairCount()
    val brokenCount: LiveData<Int> = assetDao.getBrokenCount()

    suspend fun insertAsset(asset: Asset): Long = assetDao.insertAsset(asset)
    suspend fun updateAsset(asset: Asset) = assetDao.updateAsset(asset)
    suspend fun deleteAsset(assetId: Long) = assetDao.softDeleteAsset(assetId)
    fun getAssetById(assetId: Long) = assetDao.getAssetById(assetId)
    suspend fun getAssetByIdSync(assetId: Long) = assetDao.getAssetByIdSync(assetId)
    fun searchAssets(query: String) = assetDao.searchAssets(query)
    fun getAssetsByCategory(category: String) = assetDao.getAssetsByCategory(category)
    suspend fun updateAssetCondition(assetId: Long, condition: String) =
        assetDao.updateAssetCondition(assetId, condition)
    suspend fun getAllAssetsList(): List<Asset> = assetDao.getAllActiveAssetsList()
    suspend fun getAssetsForHealthCheck(limit: Int = 50) = assetDao.getAssetsForHealthCheck(limit)

    // Health Checks
    fun getHealthChecksForAsset(assetId: Long) = healthCheckDao.getHealthChecksForAsset(assetId)
    suspend fun insertHealthCheck(healthCheck: HealthCheck): Long =
        healthCheckDao.insertHealthCheck(healthCheck)
    fun getRecentHealthChecks(limit: Int = 20) = healthCheckDao.getRecentHealthChecks(limit)
    suspend fun getHealthChecksBetweenDates(startDate: Long, endDate: Long) =
        healthCheckDao.getHealthChecksBetweenDates(startDate, endDate)

    // Issue Logs
    val allIssueLogs: LiveData<List<IssueLog>> = issueLogDao.getAllIssueLogs()
    val unresolvedIssues: LiveData<List<IssueLog>> = issueLogDao.getUnresolvedIssues()
    val unresolvedIssueCount: LiveData<Int> = issueLogDao.getUnresolvedIssueCount()

    suspend fun insertIssueLog(issueLog: IssueLog): Long = issueLogDao.insertIssueLog(issueLog)
    fun getIssueLogsForAsset(assetId: Long) = issueLogDao.getIssueLogsForAsset(assetId)
    suspend fun resolveIssue(issueId: Long, notes: String) = issueLogDao.resolveIssue(issueId, notes = notes)
    suspend fun getIssuesBetweenDates(startDate: Long, endDate: Long) =
        issueLogDao.getIssuesBetweenDates(startDate, endDate)

    // Repair Requests
    val allRepairRequests: LiveData<List<RepairRequest>> = repairRequestDao.getAllRepairRequests()
    val pendingRepairRequests: LiveData<List<RepairRequest>> = repairRequestDao.getPendingRepairRequests()
    val pendingRepairCount: LiveData<Int> = repairRequestDao.getPendingRepairCount()

    suspend fun insertRepairRequest(repairRequest: RepairRequest): Long =
        repairRequestDao.insertRepairRequest(repairRequest)
    fun getRepairRequestsForAsset(assetId: Long) = repairRequestDao.getRepairRequestsForAsset(assetId)
    suspend fun updateRepairStatus(requestId: Long, status: String, notes: String) =
        repairRequestDao.updateRepairStatus(requestId, status, notes)
    suspend fun getRepairsBetweenDates(startDate: Long, endDate: Long) =
        repairRequestDao.getRepairsBetweenDates(startDate, endDate)
}
