package com.nammashaaleinventory.ui.assets

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.R
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.databinding.ActivityAddEditAssetBinding
import com.nammashaaleinventory.ui.camera.CameraActivity
import java.io.File

class AddEditAssetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditAssetBinding

    private val viewModel: AssetsViewModel by viewModels {
        AssetsViewModelFactory((application as NammaShaaleApp).repository)
    }

    private var editingAsset: Asset? = null
    private var capturedPhotoPath: String? = null

    companion object {
        const val EXTRA_ASSET_ID = "extra_asset_id"
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) launchCamera()
        else Toast.makeText(this, "Camera permission required for photos", Toast.LENGTH_SHORT).show()
    }

    private val cameraResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val photoPath = result.data?.getStringExtra(CameraActivity.EXTRA_PHOTO_PATH)
            if (photoPath != null) {
                capturedPhotoPath = photoPath
                Glide.with(this).load(File(photoPath)).centerCrop().into(binding.ivAssetPhoto)
                binding.tvPhotoStatus.text = "Photo captured"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditAssetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        setupCategoryDropdown()
        setupConditionDropdown()
        setupClickListeners()
        observeStatus()

        // Check if editing
        val assetId = intent.getLongExtra(EXTRA_ASSET_ID, -1L)
        if (assetId != -1L) {
            loadAsset(assetId)
            supportActionBar?.title = "Edit Asset"
        } else {
            supportActionBar?.title = "Add New Asset"
        }
    }

    private fun setupCategoryDropdown() {
        val categories = arrayOf("Sports", "Lab", "Technology", "Furniture", "Other")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, categories)
        binding.actvCategory.setAdapter(adapter)
        binding.actvCategory.setText(categories[0], false)
    }

    private fun setupConditionDropdown() {
        val conditions = arrayOf("Working", "Needs Repair", "Broken")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, conditions)
        binding.actvCondition.setAdapter(adapter)
        binding.actvCondition.setText(conditions[0], false)
    }

    private fun setupClickListeners() {
        binding.btnCapturePhoto.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                launchCamera()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnSaveAsset.setOnClickListener {
            saveAsset()
        }
    }

    private fun launchCamera() {
        val intent = Intent(this, CameraActivity::class.java)
        cameraResultLauncher.launch(intent)
    }

    private fun loadAsset(assetId: Long) {
        (application as NammaShaaleApp).repository.getAssetById(assetId).observe(this) { asset ->
            if (asset != null && editingAsset == null) {
                editingAsset = asset
                populateForm(asset)
            }
        }
    }

    private fun populateForm(asset: Asset) {
        binding.apply {
            etAssetName.setText(asset.name)
            etSerialNumber.setText(asset.serialNumber)
            etDescription.setText(asset.description)
            etLocation.setText(asset.location)
            actvCategory.setText(asset.category, false)

            val conditionText = when (asset.condition) {
                "WORKING" -> "Working"
                "NEEDS_REPAIR" -> "Needs Repair"
                "BROKEN" -> "Broken"
                else -> "Working"
            }
            actvCondition.setText(conditionText, false)

            asset.photoPath?.let { path ->
                val file = File(path)
                if (file.exists()) {
                    capturedPhotoPath = path
                    Glide.with(this@AddEditAssetActivity).load(file).centerCrop().into(ivAssetPhoto)
                    tvPhotoStatus.text = "Photo loaded"
                }
            }
        }
    }

    private fun saveAsset() {
        val name = binding.etAssetName.text?.toString()?.trim() ?: ""
        val serialNumber = binding.etSerialNumber.text?.toString()?.trim() ?: ""
        val category = binding.actvCategory.text?.toString() ?: "Other"
        val conditionText = binding.actvCondition.text?.toString() ?: "Working"
        val description = binding.etDescription.text?.toString()?.trim() ?: ""
        val location = binding.etLocation.text?.toString()?.trim() ?: ""

        if (name.isBlank()) {
            binding.tilAssetName.error = "Asset name is required"
            return
        }
        if (serialNumber.isBlank()) {
            binding.tilSerialNumber.error = "Serial number is required"
            return
        }

        val condition = when (conditionText) {
            "Needs Repair" -> "NEEDS_REPAIR"
            "Broken" -> "BROKEN"
            else -> "WORKING"
        }

        val asset = editingAsset?.copy(
            name = name,
            serialNumber = serialNumber,
            category = category,
            condition = condition,
            description = description,
            location = location,
            photoPath = capturedPhotoPath ?: editingAsset?.photoPath,
            lastUpdated = System.currentTimeMillis()
        ) ?: Asset(
            name = name,
            serialNumber = serialNumber,
            category = category,
            condition = condition,
            description = description,
            location = location,
            photoPath = capturedPhotoPath
        )

        if (editingAsset != null) {
            viewModel.updateAsset(asset)
        } else {
            viewModel.insertAsset(asset)
        }
    }

    private fun observeStatus() {
        viewModel.operationStatus.observe(this) { status ->
            if (status != null) {
                Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
                viewModel.clearStatus()
                finish()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
