package com.nammashaaleinventory.ui.issuelog

import androidx.lifecycle.*
import com.nammashaaleinventory.data.entities.IssueLog
import com.nammashaaleinventory.data.repository.AssetRepository
import kotlinx.coroutines.launch

class IssueLogViewModel(private val repository: AssetRepository) : ViewModel() {

    private val _showUnresolvedOnly = MutableLiveData(true)

    val issueLogs: LiveData<List<IssueLog>> = _showUnresolvedOnly.switchMap { unresolvedOnly ->
        if (unresolvedOnly) repository.unresolvedIssues else repository.allIssueLogs
    }

    val unresolvedCount = repository.unresolvedIssueCount

    fun showUnresolvedOnly(unresolvedOnly: Boolean) {
        _showUnresolvedOnly.value = unresolvedOnly
    }

    fun insertIssueLog(issueLog: IssueLog) = viewModelScope.launch {
        repository.insertIssueLog(issueLog)
    }

    fun resolveIssue(issueId: Long, notes: String) = viewModelScope.launch {
        repository.resolveIssue(issueId, notes)
    }
}

class IssueLogViewModelFactory(private val repository: AssetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(IssueLogViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return IssueLogViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
