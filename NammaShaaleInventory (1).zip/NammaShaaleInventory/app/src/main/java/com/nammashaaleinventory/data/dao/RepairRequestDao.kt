package com.nammashaaleinventory.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammashaaleinventory.data.entities.RepairRequest

@Dao
interface RepairRequestDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepairRequest(repairRequest: RepairRequest): Long

    @Update
    suspend fun updateRepairRequest(repairRequest: RepairRequest)

    @Delete
    suspend fun deleteRepairRequest(repairRequest: RepairRequest)

    @Query("SELECT * FROM repair_requests ORDER BY requestDate DESC")
    fun getAllRepairRequests(): LiveData<List<RepairRequest>>

    @Query("SELECT * FROM repair_requests WHERE assetId = :assetId ORDER BY requestDate DESC")
    fun getRepairRequestsForAsset(assetId: Long): LiveData<List<RepairRequest>>

    @Query("SELECT * FROM repair_requests WHERE status = 'PENDING' ORDER BY requestDate DESC")
    fun getPendingRepairRequests(): LiveData<List<RepairRequest>>

    @Query("SELECT COUNT(*) FROM repair_requests WHERE status = 'PENDING'")
    fun getPendingRepairCount(): LiveData<Int>

    @Query("SELECT * FROM repair_requests WHERE status IN ('PENDING', 'APPROVED', 'IN_PROGRESS') ORDER BY requestDate DESC")
    fun getActiveRepairRequests(): LiveData<List<RepairRequest>>

    @Query("UPDATE repair_requests SET status = :status, sdmcNotes = :notes WHERE id = :requestId")
    suspend fun updateRepairStatus(requestId: Long, status: String, notes: String = "")

    @Query("SELECT * FROM repair_requests WHERE requestDate BETWEEN :startDate AND :endDate ORDER BY requestDate DESC")
    suspend fun getRepairsBetweenDates(startDate: Long, endDate: Long): List<RepairRequest>
}
