package com.nammashaaleinventory.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "health_checks",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["assetId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("assetId")]
)
data class HealthCheck(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val assetId: Long,
    val condition: String, // WORKING, NEEDS_REPAIR, BROKEN
    val notes: String = "",
    val checkedBy: String = "",
    val checkDate: Long = System.currentTimeMillis(),
    val photoPath: String? = null
) : Parcelable
