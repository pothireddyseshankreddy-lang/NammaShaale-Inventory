package com.nammashaaleinventory.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.nammashaaleinventory.data.dao.AssetDao
import com.nammashaaleinventory.data.dao.HealthCheckDao
import com.nammashaaleinventory.data.dao.IssueLogDao
import com.nammashaaleinventory.data.dao.RepairRequestDao
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.data.entities.HealthCheck
import com.nammashaaleinventory.data.entities.IssueLog
import com.nammashaaleinventory.data.entities.RepairRequest

@Database(
    entities = [Asset::class, HealthCheck::class, IssueLog::class, RepairRequest::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun assetDao(): AssetDao
    abstract fun healthCheckDao(): HealthCheckDao
    abstract fun issueLogDao(): IssueLogDao
    abstract fun repairRequestDao(): RepairRequestDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "namma_shaale_inventory.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
