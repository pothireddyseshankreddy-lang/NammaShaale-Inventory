package com.nammashaaleinventory.ui.repair

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.databinding.FragmentRepairBinding

class RepairFragment : Fragment() {

    private var _binding: FragmentRepairBinding? = null
    private val binding get() = _binding!!

    private val viewModel: RepairViewModel by viewModels {
        RepairViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    private lateinit var adapter: RepairRequestAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRepairBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupTabs()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = RepairRequestAdapter { request, newStatus ->
            viewModel.updateRepairStatus(request.id, newStatus, "")
        }
        binding.rvRepairRequests.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRepairRequests.adapter = adapter
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.showPendingOnly(true)
                    1 -> viewModel.showPendingOnly(false)
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun observeData() {
        viewModel.repairRequests.observe(viewLifecycleOwner) { requests ->
            adapter.submitList(requests)
            binding.tvEmptyState.visibility = if (requests.isEmpty()) View.VISIBLE else View.GONE
            binding.rvRepairRequests.visibility = if (requests.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.pendingCount.observe(viewLifecycleOwner) { count ->
            binding.tvPendingBadge.text = "$count pending"
            binding.tvPendingBadge.visibility = if (count > 0) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
