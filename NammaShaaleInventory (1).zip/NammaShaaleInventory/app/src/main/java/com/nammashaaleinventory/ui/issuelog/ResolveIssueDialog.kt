package com.nammashaaleinventory.ui.issuelog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.databinding.DialogResolveIssueBinding

class ResolveIssueDialog : DialogFragment() {

    private var _binding: DialogResolveIssueBinding? = null
    private val binding get() = _binding!!

    private val viewModel: IssueLogViewModel by viewModels {
        IssueLogViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    companion object {
        private const val ARG_ISSUE_ID = "issue_id"
        fun newInstance(issueId: Long) = ResolveIssueDialog().apply {
            arguments = Bundle().apply { putLong(ARG_ISSUE_ID, issueId) }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogResolveIssueBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnConfirmResolve.setOnClickListener {
            val issueId = requireArguments().getLong(ARG_ISSUE_ID)
            val notes = binding.etResolutionNotes.text?.toString()?.trim() ?: ""
            viewModel.resolveIssue(issueId, notes)
            Toast.makeText(requireContext(), "Issue marked as resolved", Toast.LENGTH_SHORT).show()
            dismiss()
        }

        binding.btnCancelResolve.setOnClickListener { dismiss() }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
