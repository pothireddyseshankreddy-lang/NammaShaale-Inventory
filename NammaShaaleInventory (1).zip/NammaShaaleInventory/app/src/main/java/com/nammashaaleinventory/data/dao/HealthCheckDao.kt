package com.nammashaaleinventory.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammashaaleinventory.data.entities.HealthCheck

@Dao
interface HealthCheckDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHealthCheck(healthCheck: HealthCheck): Long

    @Update
    suspend fun updateHealthCheck(healthCheck: HealthCheck)

    @Delete
    suspend fun deleteHealthCheck(healthCheck: HealthCheck)

    @Query("SELECT * FROM health_checks WHERE assetId = :assetId ORDER BY checkDate DESC")
    fun getHealthChecksForAsset(assetId: Long): LiveData<List<HealthCheck>>

    @Query("SELECT * FROM health_checks WHERE assetId = :assetId ORDER BY checkDate DESC LIMIT 1")
    suspend fun getLatestHealthCheckForAsset(assetId: Long): HealthCheck?

    @Query("SELECT * FROM health_checks ORDER BY checkDate DESC LIMIT :limit")
    fun getRecentHealthChecks(limit: Int = 20): LiveData<List<HealthCheck>>

    @Query("SELECT COUNT(*) FROM health_checks WHERE checkDate > :since")
    fun getHealthCheckCountSince(since: Long): LiveData<Int>

    @Query("SELECT * FROM health_checks WHERE checkDate BETWEEN :startDate AND :endDate ORDER BY checkDate DESC")
    suspend fun getHealthChecksBetweenDates(startDate: Long, endDate: Long): List<HealthCheck>
}
