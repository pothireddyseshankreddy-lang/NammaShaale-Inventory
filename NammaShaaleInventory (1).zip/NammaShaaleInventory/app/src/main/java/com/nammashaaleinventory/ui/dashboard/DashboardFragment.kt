package com.nammashaaleinventory.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.R
import com.nammashaaleinventory.databinding.FragmentDashboardBinding
import com.nammashaaleinventory.ui.healthcheck.HealthCheckActivity
import com.nammashaaleinventory.ui.reports.ReportActivity

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val viewModel: DashboardViewModel by viewModels {
        DashboardViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        observeData()
        setupClickListeners()
    }

    private fun observeData() {
        viewModel.dashboardSummary.observe(viewLifecycleOwner) { summary ->
            binding.apply {
                tvTotalAssets.text = summary.totalAssets.toString()
                tvWorkingCount.text = summary.workingCount.toString()
                tvNeedsRepairCount.text = summary.needsRepairCount.toString()
                tvBrokenCount.text = summary.brokenCount.toString()
                tvPendingRepairsCount.text = summary.pendingRepairs.toString()
                tvUnresolvedIssuesCount.text = summary.unresolvedIssues.toString()

                // Update progress bar
                val total = summary.totalAssets.coerceAtLeast(1)
                val healthPct = (summary.workingCount * 100) / total
                progressAssetHealth.progress = healthPct
                tvHealthPercentage.text = "$healthPct% Assets Healthy"

                // Alert badges
                cardAlertRepair.visibility = if (summary.needsRepairCount > 0) View.VISIBLE else View.GONE
                cardAlertIssue.visibility = if (summary.unresolvedIssues > 0) View.VISIBLE else View.GONE
            }
        }
    }

    private fun setupClickListeners() {
        binding.apply {
            btnAddAsset.setOnClickListener {
                findNavController().navigate(R.id.action_dashboard_to_assets)
            }

            btnStartHealthCheck.setOnClickListener {
                startActivity(Intent(requireContext(), HealthCheckActivity::class.java))
            }

            btnGenerateReport.setOnClickListener {
                startActivity(Intent(requireContext(), ReportActivity::class.java))
            }

            cardTotalAssets.setOnClickListener {
                findNavController().navigate(R.id.action_dashboard_to_assets)
            }

            cardNeedsRepair.setOnClickListener {
                findNavController().navigate(R.id.action_dashboard_to_repair)
            }

            cardIssues.setOnClickListener {
                findNavController().navigate(R.id.action_dashboard_to_issues)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
