package com.nammashaaleinventory.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "assets")
data class Asset(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val serialNumber: String,
    val category: String, // Sports, Lab, Technology, Furniture, Other
    val description: String = "",
    val photoPath: String? = null,
    val condition: String = "WORKING", // WORKING, NEEDS_REPAIR, BROKEN
    val location: String = "", // e.g., "Room 101", "Sports Ground"
    val purchaseDate: Long? = null,
    val purchaseValue: Double = 0.0,
    val addedDate: Long = System.currentTimeMillis(),
    val lastUpdated: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
) : Parcelable
