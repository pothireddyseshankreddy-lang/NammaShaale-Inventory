package com.nammashaaleinventory.ui.repair

import androidx.lifecycle.*
import com.nammashaaleinventory.data.entities.RepairRequest
import com.nammashaaleinventory.data.repository.AssetRepository
import kotlinx.coroutines.launch

class RepairViewModel(private val repository: AssetRepository) : ViewModel() {

    private val _showPendingOnly = MutableLiveData(true)

    val repairRequests: LiveData<List<RepairRequest>> = _showPendingOnly.switchMap { pendingOnly ->
        if (pendingOnly) repository.pendingRepairRequests else repository.allRepairRequests
    }

    val pendingCount = repository.pendingRepairCount

    fun showPendingOnly(pendingOnly: Boolean) {
        _showPendingOnly.value = pendingOnly
    }

    fun insertRepairRequest(repairRequest: RepairRequest) = viewModelScope.launch {
        repository.insertRepairRequest(repairRequest)
    }

    fun updateRepairStatus(requestId: Long, status: String, notes: String) = viewModelScope.launch {
        repository.updateRepairStatus(requestId, status, notes)
    }
}

class RepairViewModelFactory(private val repository: AssetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(RepairViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return RepairViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
