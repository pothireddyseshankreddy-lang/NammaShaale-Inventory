package com.nammashaaleinventory.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammashaaleinventory.data.entities.IssueLog

@Dao
interface IssueLogDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssueLog(issueLog: IssueLog): Long

    @Update
    suspend fun updateIssueLog(issueLog: IssueLog)

    @Delete
    suspend fun deleteIssueLog(issueLog: IssueLog)

    @Query("SELECT * FROM issue_logs ORDER BY issueDate DESC")
    fun getAllIssueLogs(): LiveData<List<IssueLog>>

    @Query("SELECT * FROM issue_logs WHERE assetId = :assetId ORDER BY issueDate DESC")
    fun getIssueLogsForAsset(assetId: Long): LiveData<List<IssueLog>>

    @Query("SELECT * FROM issue_logs WHERE isResolved = 0 ORDER BY issueDate DESC")
    fun getUnresolvedIssues(): LiveData<List<IssueLog>>

    @Query("SELECT COUNT(*) FROM issue_logs WHERE isResolved = 0")
    fun getUnresolvedIssueCount(): LiveData<Int>

    @Query("UPDATE issue_logs SET isResolved = 1, resolvedDate = :resolvedDate, resolutionNotes = :notes WHERE id = :issueId")
    suspend fun resolveIssue(issueId: Long, resolvedDate: Long = System.currentTimeMillis(), notes: String = "")

    @Query("SELECT * FROM issue_logs WHERE issueDate BETWEEN :startDate AND :endDate ORDER BY issueDate DESC")
    suspend fun getIssuesBetweenDates(startDate: Long, endDate: Long): List<IssueLog>
}
