package com.nammashaaleinventory.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "repair_requests",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["assetId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("assetId")]
)
data class RepairRequest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val assetId: Long,
    val priority: String = "MEDIUM", // LOW, MEDIUM, HIGH, URGENT
    val description: String,
    val requestedBy: String = "",
    val requestDate: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // PENDING, APPROVED, IN_PROGRESS, COMPLETED, REJECTED
    val estimatedCost: Double = 0.0,
    val sdmcNotes: String = "",
    val completedDate: Long? = null
) : Parcelable
