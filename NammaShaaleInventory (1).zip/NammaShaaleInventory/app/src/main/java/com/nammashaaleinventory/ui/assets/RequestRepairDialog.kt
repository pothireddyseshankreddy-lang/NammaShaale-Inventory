package com.nammashaaleinventory.ui.assets

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.data.entities.RepairRequest
import com.nammashaaleinventory.databinding.DialogRequestRepairBinding
import com.nammashaaleinventory.ui.repair.RepairViewModel
import com.nammashaaleinventory.ui.repair.RepairViewModelFactory

class RequestRepairDialog : DialogFragment() {

    private var _binding: DialogRequestRepairBinding? = null
    private val binding get() = _binding!!

    private val viewModel: RepairViewModel by viewModels {
        RepairViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    companion object {
        private const val ARG_ASSET_ID = "asset_id"

        fun newInstance(assetId: Long): RequestRepairDialog {
            return RequestRepairDialog().apply {
                arguments = Bundle().apply { putLong(ARG_ASSET_ID, assetId) }
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = DialogRequestRepairBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val priorities = arrayOf("Low", "Medium", "High", "Urgent")
        binding.actvPriority.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, priorities)
        )
        binding.actvPriority.setText("Medium", false)

        binding.btnSubmitRepair.setOnClickListener {
            val assetId = requireArguments().getLong(ARG_ASSET_ID)
            val priorityText = binding.actvPriority.text.toString()
            val description = binding.etRepairDescription.text?.toString()?.trim() ?: ""
            val requestedBy = binding.etRequestedBy.text?.toString()?.trim() ?: ""
            val estimatedCostStr = binding.etEstimatedCost.text?.toString()?.trim() ?: "0"

            if (description.isBlank()) {
                binding.tilRepairDescription.error = "Please describe the repair needed"
                return@setOnClickListener
            }

            val priority = priorityText.uppercase()
            val estimatedCost = estimatedCostStr.toDoubleOrNull() ?: 0.0

            val repairRequest = RepairRequest(
                assetId = assetId,
                priority = priority,
                description = description,
                requestedBy = requestedBy,
                estimatedCost = estimatedCost
            )
            viewModel.insertRepairRequest(repairRequest)
            Toast.makeText(requireContext(), "Repair request submitted to SDMC", Toast.LENGTH_SHORT).show()
            dismiss()
        }

        binding.btnCancelRepair.setOnClickListener { dismiss() }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
