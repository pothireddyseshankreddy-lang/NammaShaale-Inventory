package com.nammashaaleinventory.ui.assets

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nammashaaleinventory.R
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.databinding.ItemAssetBinding
import java.io.File

class AssetAdapter(private val onItemClick: (Asset) -> Unit) :
    ListAdapter<Asset, AssetAdapter.AssetViewHolder>(AssetDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AssetViewHolder {
        val binding = ItemAssetBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AssetViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AssetViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AssetViewHolder(private val binding: ItemAssetBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(asset: Asset) {
            binding.apply {
                tvAssetName.text = asset.name
                tvSerialNumber.text = "S/N: ${asset.serialNumber}"
                tvCategory.text = asset.category
                tvLocation.text = if (asset.location.isNotBlank()) asset.location else "No location set"

                // Condition indicator
                val (conditionText, conditionColor, conditionIcon) = when (asset.condition) {
                    "WORKING" -> Triple("Working", R.color.condition_green, R.drawable.ic_check_circle)
                    "NEEDS_REPAIR" -> Triple("Needs Repair", R.color.condition_yellow, R.drawable.ic_warning)
                    "BROKEN" -> Triple("Broken", R.color.condition_red, R.drawable.ic_error)
                    else -> Triple("Unknown", R.color.condition_grey, R.drawable.ic_help)
                }
                tvCondition.text = conditionText
                tvCondition.setTextColor(ContextCompat.getColor(root.context, conditionColor))
                ivConditionIcon.setImageResource(conditionIcon)
                ivConditionIcon.setColorFilter(ContextCompat.getColor(root.context, conditionColor))
                viewConditionBar.setBackgroundColor(ContextCompat.getColor(root.context, conditionColor))

                // Load photo
                if (asset.photoPath != null) {
                    val photoFile = File(asset.photoPath)
                    if (photoFile.exists()) {
                        Glide.with(root.context)
                            .load(photoFile)
                            .centerCrop()
                            .placeholder(R.drawable.ic_asset_placeholder)
                            .into(ivAssetPhoto)
                    } else {
                        ivAssetPhoto.setImageResource(R.drawable.ic_asset_placeholder)
                    }
                } else {
                    ivAssetPhoto.setImageResource(R.drawable.ic_asset_placeholder)
                }

                root.setOnClickListener { onItemClick(asset) }
            }
        }
    }

    class AssetDiffCallback : DiffUtil.ItemCallback<Asset>() {
        override fun areItemsTheSame(oldItem: Asset, newItem: Asset) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Asset, newItem: Asset) = oldItem == newItem
    }
}
