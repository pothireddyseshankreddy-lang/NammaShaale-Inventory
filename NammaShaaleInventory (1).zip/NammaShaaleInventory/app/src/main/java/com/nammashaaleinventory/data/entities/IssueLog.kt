package com.nammashaaleinventory.data.entities

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(
    tableName = "issue_logs",
    foreignKeys = [
        ForeignKey(
            entity = Asset::class,
            parentColumns = ["id"],
            childColumns = ["assetId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("assetId")]
)
data class IssueLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val assetId: Long,
    val issueType: String, // LOST, DAMAGED, STOLEN, MALFUNCTION, OTHER
    val description: String,
    val reportedBy: String = "",
    val issueDate: Long = System.currentTimeMillis(),
    val resolvedDate: Long? = null,
    val isResolved: Boolean = false,
    val resolutionNotes: String = ""
) : Parcelable
