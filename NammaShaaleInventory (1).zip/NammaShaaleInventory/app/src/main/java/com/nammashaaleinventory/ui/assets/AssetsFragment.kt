package com.nammashaaleinventory.ui.assets

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.R
import com.nammashaaleinventory.databinding.FragmentAssetsBinding

class AssetsFragment : Fragment() {

    private var _binding: FragmentAssetsBinding? = null
    private val binding get() = _binding!!

    private val viewModel: AssetsViewModel by viewModels {
        AssetsViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    private lateinit var assetAdapter: AssetAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAssetsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupSearch()
        setupCategoryChips()
        setupFab()
        observeData()
        setupMenu()
    }

    private fun setupRecyclerView() {
        assetAdapter = AssetAdapter { asset ->
            val intent = Intent(requireContext(), AssetDetailActivity::class.java)
            intent.putExtra(AssetDetailActivity.EXTRA_ASSET_ID, asset.id)
            startActivity(intent)
        }
        binding.rvAssets.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = assetAdapter
        }
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = true
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.setSearchQuery(newText ?: "")
                return true
            }
        })
    }

    private fun setupCategoryChips() {
        val categories = listOf("All", "Sports", "Lab", "Technology", "Furniture", "Other")
        categories.forEach { category ->
            val chip = Chip(requireContext()).apply {
                text = category
                isCheckable = true
                isChecked = category == "All"
                setOnClickListener {
                    viewModel.setCategoryFilter(if (category == "All") null else category)
                }
            }
            binding.chipGroupCategory.addView(chip)
        }
    }

    private fun setupFab() {
        binding.fabAddAsset.setOnClickListener {
            startActivity(Intent(requireContext(), AddEditAssetActivity::class.java))
        }
    }

    private fun observeData() {
        viewModel.assets.observe(viewLifecycleOwner) { assets ->
            assetAdapter.submitList(assets)
            binding.tvEmptyState.visibility = if (assets.isEmpty()) View.VISIBLE else View.GONE
            binding.rvAssets.visibility = if (assets.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.assets_menu, menu)
            }
            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId) {
                    R.id.action_filter_working -> { viewModel.setCategoryFilter(null); true }
                    else -> false
                }
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
