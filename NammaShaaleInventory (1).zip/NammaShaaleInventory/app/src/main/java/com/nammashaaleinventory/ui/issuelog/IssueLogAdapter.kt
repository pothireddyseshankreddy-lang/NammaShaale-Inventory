package com.nammashaaleinventory.ui.issuelog

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammashaaleinventory.R
import com.nammashaaleinventory.data.entities.IssueLog
import com.nammashaaleinventory.databinding.ItemIssueLogBinding
import com.nammashaaleinventory.utils.DateUtils

class IssueLogAdapter(private val onResolveClick: (IssueLog) -> Unit) :
    ListAdapter<IssueLog, IssueLogAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemIssueLogBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemIssueLogBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(issueLog: IssueLog) {
            binding.apply {
                tvIssueType.text = formatIssueType(issueLog.issueType)
                tvIssueDescription.text = issueLog.description
                tvIssueDate.text = DateUtils.formatDate(issueLog.issueDate)
                tvReportedBy.text = if (issueLog.reportedBy.isNotBlank())
                    "By: ${issueLog.reportedBy}" else "Reporter not specified"

                if (issueLog.isResolved) {
                    tvStatus.text = "Resolved"
                    tvStatus.setBackgroundTintList(
                        ContextCompat.getColorStateList(root.context, R.color.condition_green)
                    )
                    btnResolve.isEnabled = false
                    btnResolve.text = "Resolved"
                } else {
                    tvStatus.text = "Open"
                    tvStatus.setBackgroundTintList(
                        ContextCompat.getColorStateList(root.context, R.color.condition_red)
                    )
                    btnResolve.isEnabled = true
                    btnResolve.text = "Mark Resolved"
                    btnResolve.setOnClickListener { onResolveClick(issueLog) }
                }

                // Issue type icon color
                val typeColor = when (issueLog.issueType) {
                    "LOST", "STOLEN" -> R.color.condition_red
                    "DAMAGED", "BROKEN" -> R.color.condition_yellow
                    else -> R.color.primary_blue
                }
                tvIssueType.setTextColor(ContextCompat.getColor(root.context, typeColor))
            }
        }

        private fun formatIssueType(type: String) = when (type) {
            "LOST" -> "🔴 Lost"
            "DAMAGED" -> "🟡 Damaged"
            "STOLEN" -> "🔴 Stolen"
            "MALFUNCTION" -> "🟠 Malfunction"
            else -> "ℹ️ Other"
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<IssueLog>() {
        override fun areItemsTheSame(oldItem: IssueLog, newItem: IssueLog) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: IssueLog, newItem: IssueLog) = oldItem == newItem
    }
}
