package com.nammashaaleinventory

import android.app.Application
import com.nammashaaleinventory.data.AppDatabase
import com.nammashaaleinventory.data.repository.AssetRepository

class NammaShaaleApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    val repository: AssetRepository by lazy {
        AssetRepository(
            database.assetDao(),
            database.healthCheckDao(),
            database.issueLogDao(),
            database.repairRequestDao()
        )
    }
}
