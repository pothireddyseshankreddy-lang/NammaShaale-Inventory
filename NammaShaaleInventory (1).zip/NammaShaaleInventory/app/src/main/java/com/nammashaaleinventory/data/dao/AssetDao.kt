package com.nammashaaleinventory.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.nammashaaleinventory.data.entities.Asset

@Dao
interface AssetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAsset(asset: Asset): Long

    @Update
    suspend fun updateAsset(asset: Asset)

    @Delete
    suspend fun deleteAsset(asset: Asset)

    @Query("SELECT * FROM assets WHERE isActive = 1 ORDER BY name ASC")
    fun getAllActiveAssets(): LiveData<List<Asset>>

    @Query("SELECT * FROM assets WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getAllActiveAssetsList(): List<Asset>

    @Query("SELECT * FROM assets WHERE id = :assetId")
    fun getAssetById(assetId: Long): LiveData<Asset>

    @Query("SELECT * FROM assets WHERE id = :assetId")
    suspend fun getAssetByIdSync(assetId: Long): Asset?

    @Query("SELECT * FROM assets WHERE condition = :condition AND isActive = 1")
    fun getAssetsByCondition(condition: String): LiveData<List<Asset>>

    @Query("SELECT * FROM assets WHERE category = :category AND isActive = 1 ORDER BY name ASC")
    fun getAssetsByCategory(category: String): LiveData<List<Asset>>

    @Query("SELECT COUNT(*) FROM assets WHERE isActive = 1")
    fun getTotalAssetsCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM assets WHERE condition = 'NEEDS_REPAIR' AND isActive = 1")
    fun getNeedsRepairCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM assets WHERE condition = 'BROKEN' AND isActive = 1")
    fun getBrokenCount(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM assets WHERE condition = 'WORKING' AND isActive = 1")
    fun getWorkingCount(): LiveData<Int>

    @Query("SELECT * FROM assets WHERE (name LIKE '%' || :query || '%' OR serialNumber LIKE '%' || :query || '%') AND isActive = 1 ORDER BY name ASC")
    fun searchAssets(query: String): LiveData<List<Asset>>

    @Query("UPDATE assets SET isActive = 0 WHERE id = :assetId")
    suspend fun softDeleteAsset(assetId: Long)

    @Query("UPDATE assets SET condition = :condition, lastUpdated = :timestamp WHERE id = :assetId")
    suspend fun updateAssetCondition(assetId: Long, condition: String, timestamp: Long = System.currentTimeMillis())

    @Query("SELECT * FROM assets WHERE isActive = 1 ORDER BY lastUpdated ASC LIMIT :limit")
    suspend fun getAssetsForHealthCheck(limit: Int = 50): List<Asset>
}
