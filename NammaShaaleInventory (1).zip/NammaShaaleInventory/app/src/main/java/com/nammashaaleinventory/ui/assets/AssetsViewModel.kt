package com.nammashaaleinventory.ui.assets

import androidx.lifecycle.*
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.data.repository.AssetRepository
import kotlinx.coroutines.launch

class AssetsViewModel(private val repository: AssetRepository) : ViewModel() {

    private val _searchQuery = MutableLiveData<String>("")
    private val _categoryFilter = MutableLiveData<String?>(null)

    val assets: LiveData<List<Asset>> = _searchQuery.switchMap { query ->
        if (query.isNullOrBlank()) {
            _categoryFilter.switchMap { category ->
                if (category.isNullOrBlank()) {
                    repository.allAssets
                } else {
                    repository.getAssetsByCategory(category)
                }
            }
        } else {
            repository.searchAssets(query)
        }
    }

    private val _operationStatus = MutableLiveData<String?>()
    val operationStatus: LiveData<String?> = _operationStatus

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: String?) {
        _categoryFilter.value = category
    }

    fun insertAsset(asset: Asset) = viewModelScope.launch {
        val id = repository.insertAsset(asset)
        _operationStatus.value = if (id > 0) "Asset added successfully" else "Failed to add asset"
    }

    fun updateAsset(asset: Asset) = viewModelScope.launch {
        repository.updateAsset(asset)
        _operationStatus.value = "Asset updated successfully"
    }

    fun deleteAsset(assetId: Long) = viewModelScope.launch {
        repository.deleteAsset(assetId)
        _operationStatus.value = "Asset removed"
    }

    fun clearStatus() {
        _operationStatus.value = null
    }
}

class AssetsViewModelFactory(private val repository: AssetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AssetsViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AssetsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
