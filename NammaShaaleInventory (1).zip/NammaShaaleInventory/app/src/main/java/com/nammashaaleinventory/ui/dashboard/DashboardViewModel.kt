package com.nammashaaleinventory.ui.dashboard

import androidx.lifecycle.*
import com.nammashaaleinventory.data.repository.AssetRepository
import kotlinx.coroutines.launch

class DashboardViewModel(private val repository: AssetRepository) : ViewModel() {

    val totalAssets = repository.totalCount
    val workingCount = repository.workingCount
    val needsRepairCount = repository.needsRepairCount
    val brokenCount = repository.brokenCount
    val pendingRepairCount = repository.pendingRepairCount
    val unresolvedIssueCount = repository.unresolvedIssueCount
    val recentHealthChecks = repository.getRecentHealthChecks(5)

    val dashboardSummary = MediatorLiveData<DashboardSummary>().apply {
        fun update() {
            val total = totalAssets.value ?: 0
            val working = workingCount.value ?: 0
            val repair = needsRepairCount.value ?: 0
            val broken = brokenCount.value ?: 0
            val pendingRepairs = pendingRepairCount.value ?: 0
            val unresolvedIssues = unresolvedIssueCount.value ?: 0
            value = DashboardSummary(total, working, repair, broken, pendingRepairs, unresolvedIssues)
        }
        addSource(totalAssets) { update() }
        addSource(workingCount) { update() }
        addSource(needsRepairCount) { update() }
        addSource(brokenCount) { update() }
        addSource(pendingRepairCount) { update() }
        addSource(unresolvedIssueCount) { update() }
    }
}

data class DashboardSummary(
    val totalAssets: Int,
    val workingCount: Int,
    val needsRepairCount: Int,
    val brokenCount: Int,
    val pendingRepairs: Int,
    val unresolvedIssues: Int
)

class DashboardViewModelFactory(private val repository: AssetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
