package com.nammashaaleinventory.ui.issuelog

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.databinding.FragmentIssueLogBinding

class IssueLogFragment : Fragment() {

    private var _binding: FragmentIssueLogBinding? = null
    private val binding get() = _binding!!

    private val viewModel: IssueLogViewModel by viewModels {
        IssueLogViewModelFactory((requireActivity().application as NammaShaaleApp).repository)
    }

    private lateinit var adapter: IssueLogAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentIssueLogBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupTabs()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = IssueLogAdapter { issueLog ->
            // Show resolve dialog
            ResolveIssueDialog.newInstance(issueLog.id).show(childFragmentManager, "resolve_issue")
        }
        binding.rvIssueLogs.layoutManager = LinearLayoutManager(requireContext())
        binding.rvIssueLogs.adapter = adapter
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.showUnresolvedOnly(true)
                    1 -> viewModel.showUnresolvedOnly(false)
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun observeData() {
        viewModel.issueLogs.observe(viewLifecycleOwner) { logs ->
            adapter.submitList(logs)
            binding.tvEmptyState.visibility = if (logs.isEmpty()) View.VISIBLE else View.GONE
            binding.rvIssueLogs.visibility = if (logs.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.unresolvedCount.observe(viewLifecycleOwner) { count ->
            binding.tvUnresolvedBadge.text = "$count unresolved"
            binding.tvUnresolvedBadge.visibility = if (count > 0) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
