package com.nammashaaleinventory.ui.healthcheck

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.nammashaaleinventory.NammaShaaleApp
import com.nammashaaleinventory.databinding.ActivityHealthCheckBinding

class HealthCheckActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHealthCheckBinding

    private val viewModel: HealthCheckViewModel by viewModels {
        HealthCheckViewModelFactory((application as NammaShaaleApp).repository)
    }

    private lateinit var adapter: HealthCheckItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHealthCheckBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Monthly Health Check"

        setupRecyclerView()
        setupButtons()
        observeData()

        viewModel.loadAssetsForCheck()
    }

    private fun setupRecyclerView() {
        adapter = HealthCheckItemAdapter { assetId, condition, notes ->
            viewModel.updateCondition(assetId, condition, notes)
        }
        binding.rvHealthCheckItems.layoutManager = LinearLayoutManager(this)
        binding.rvHealthCheckItems.adapter = adapter
    }

    private fun setupButtons() {
        binding.btnSubmitHealthCheck.setOnClickListener {
            viewModel.submitHealthCheck()
        }

        binding.btnMarkAllWorking.setOnClickListener {
            adapter.markAllWorking()
        }
    }

    private fun observeData() {
        viewModel.healthCheckItems.observe(this) { items ->
            adapter.submitList(items)
            binding.tvItemCount.text = "${items.size} items to check"
            binding.progressBar.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.checkedCount.observe(this) { count ->
            val total = adapter.itemCount
            binding.tvProgress.text = "$count / $total checked"
            binding.progressHealthCheck.progress = if (total > 0) (count * 100) / total else 0
        }

        viewModel.submitStatus.observe(this) { status ->
            when (status) {
                "success" -> {
                    Toast.makeText(this, "Health check completed! ${viewModel.checkedCount.value} items checked.", Toast.LENGTH_LONG).show()
                    finish()
                }
                "empty" -> Toast.makeText(this, "No changes to save", Toast.LENGTH_SHORT).show()
                else -> if (status != null) Toast.makeText(this, status, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}
