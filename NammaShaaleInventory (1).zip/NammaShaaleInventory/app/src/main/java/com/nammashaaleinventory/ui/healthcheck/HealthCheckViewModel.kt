package com.nammashaaleinventory.ui.healthcheck

import androidx.lifecycle.*
import com.nammashaaleinventory.data.entities.Asset
import com.nammashaaleinventory.data.entities.HealthCheck
import com.nammashaaleinventory.data.repository.AssetRepository
import kotlinx.coroutines.launch

data class HealthCheckItem(
    val asset: Asset,
    var selectedCondition: String = asset.condition,
    var notes: String = "",
    var isChecked: Boolean = false
)

class HealthCheckViewModel(private val repository: AssetRepository) : ViewModel() {

    private val _healthCheckItems = MutableLiveData<List<HealthCheckItem>>()
    val healthCheckItems: LiveData<List<HealthCheckItem>> = _healthCheckItems

    private val _checkedCount = MutableLiveData(0)
    val checkedCount: LiveData<Int> = _checkedCount

    private val _submitStatus = MutableLiveData<String?>()
    val submitStatus: LiveData<String?> = _submitStatus

    private val changedItems = mutableMapOf<Long, HealthCheckItem>()

    fun loadAssetsForCheck() = viewModelScope.launch {
        val assets = repository.getAssetsForHealthCheck(50)
        val items = assets.map { HealthCheckItem(it) }
        _healthCheckItems.value = items
    }

    fun updateCondition(assetId: Long, condition: String, notes: String) {
        val currentItems = _healthCheckItems.value?.toMutableList() ?: return
        val index = currentItems.indexOfFirst { it.asset.id == assetId }
        if (index != -1) {
            val updated = currentItems[index].copy(
                selectedCondition = condition,
                notes = notes,
                isChecked = true
            )
            currentItems[index] = updated
            changedItems[assetId] = updated
            _healthCheckItems.value = currentItems
            _checkedCount.value = currentItems.count { it.isChecked }
        }
    }

    fun submitHealthCheck() = viewModelScope.launch {
        if (changedItems.isEmpty()) {
            _submitStatus.value = "empty"
            return@launch
        }

        changedItems.values.forEach { item ->
            // Update asset condition
            repository.updateAssetCondition(item.asset.id, item.selectedCondition)

            // Record health check
            val healthCheck = HealthCheck(
                assetId = item.asset.id,
                condition = item.selectedCondition,
                notes = item.notes
            )
            repository.insertHealthCheck(healthCheck)
        }

        _submitStatus.value = "success"
    }
}

class HealthCheckViewModelFactory(private val repository: AssetRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HealthCheckViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HealthCheckViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
