package com.nammashaaleinventory.ui.repair

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nammashaaleinventory.R
import com.nammashaaleinventory.data.entities.RepairRequest
import com.nammashaaleinventory.databinding.ItemRepairRequestBinding
import com.nammashaaleinventory.utils.DateUtils

class RepairRequestAdapter(private val onStatusUpdate: (RepairRequest, String) -> Unit) :
    ListAdapter<RepairRequest, RepairRequestAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRepairRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemRepairRequestBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(request: RepairRequest) {
            binding.apply {
                tvRepairDescription.text = request.description
                tvRequestDate.text = "Requested: ${DateUtils.formatDate(request.requestDate)}"
                tvRequestedBy.text = if (request.requestedBy.isNotBlank())
                    "By: ${request.requestedBy}" else "Requester not specified"

                if (request.estimatedCost > 0) {
                    tvEstimatedCost.text = "Est. Cost: ₹${String.format("%.0f", request.estimatedCost)}"
                } else {
                    tvEstimatedCost.text = "Cost not estimated"
                }

                // Priority badge
                val (priorityText, priorityColor) = when (request.priority) {
                    "URGENT" -> "🔴 Urgent" to R.color.condition_red
                    "HIGH" -> "🟠 High" to R.color.priority_high
                    "LOW" -> "🟢 Low" to R.color.condition_green
                    else -> "🟡 Medium" to R.color.condition_yellow
                }
                tvPriority.text = priorityText
                tvPriority.setTextColor(ContextCompat.getColor(root.context, priorityColor))

                // Status chip
                val (statusText, statusColor) = when (request.status) {
                    "PENDING" -> "Pending" to R.color.condition_yellow
                    "APPROVED" -> "Approved" to R.color.primary_blue
                    "IN_PROGRESS" -> "In Progress" to R.color.priority_high
                    "COMPLETED" -> "Completed" to R.color.condition_green
                    "REJECTED" -> "Rejected" to R.color.condition_red
                    else -> "Unknown" to R.color.condition_grey
                }
                tvStatus.text = statusText
                tvStatus.setBackgroundTintList(ContextCompat.getColorStateList(root.context, statusColor))

                // Action buttons
                when (request.status) {
                    "PENDING" -> {
                        btnApprove.isEnabled = true
                        btnComplete.isEnabled = false
                        btnApprove.setOnClickListener { onStatusUpdate(request, "APPROVED") }
                    }
                    "APPROVED", "IN_PROGRESS" -> {
                        btnApprove.isEnabled = false
                        btnApprove.text = "Approved"
                        btnComplete.isEnabled = true
                        btnComplete.setOnClickListener { onStatusUpdate(request, "COMPLETED") }
                    }
                    else -> {
                        btnApprove.isEnabled = false
                        btnComplete.isEnabled = false
                    }
                }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<RepairRequest>() {
        override fun areItemsTheSame(oldItem: RepairRequest, newItem: RepairRequest) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: RepairRequest, newItem: RepairRequest) = oldItem == newItem
    }
}
